from setuptools import setup

setup(name='distributions_upload_test',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_upload_test'],
      zip_safe=False)
